import { GoogleGenAI, Type } from "@google/genai";

// Ensure the API key is available as an environment variable
if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToGenerativePart = async (blob: Blob) => {
  const base64data = await new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(blob);
  });
  return {
    inlineData: {
      data: base64data,
      mimeType: blob.type,
    },
  };
};

export const transcribeAudio = async (audioBlob: Blob): Promise<string> => {
  try {
    const audioPart = await fileToGenerativePart(audioBlob);
    const textPart = { text: "Transcribe this audio recording of a child speaking." };
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [audioPart, textPart] },
    });
    
    return response.text;
  } catch (error) {
    console.error("Error transcribing audio:", error);
    throw new Error("Could not transcribe the audio. Please try again.");
  }
};

export const generateComprehensionQuestions = async (storyText: string): Promise<string[]> => {
    if (!storyText.trim()) {
        return [];
    }

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the following story, please generate exactly 3 simple and encouraging reading comprehension questions suitable for a young child. The questions should be positive and fun.\n\n---\n${storyText}\n---`,
            config: {
                systemInstruction: "You are a fun and encouraging Reading Buddy for children aged 5-8. Generate questions that are simple, positive, and spark curiosity based on the text. Always return a valid JSON array of strings.",
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    description: "An array of three simple comprehension questions.",
                    items: {
                        type: Type.STRING
                    }
                },
            },
        });

        const jsonStr = response.text.trim();
        const questions = JSON.parse(jsonStr);
        
        if (Array.isArray(questions) && questions.length > 0) {
            return questions;
        } else {
            // Fallback for unexpected but valid JSON
            throw new Error("AI returned an unexpected format.");
        }

    } catch (error) {
        console.error("Error generating questions:", error);
        throw new Error("Could not generate questions for the story.");
    }
};